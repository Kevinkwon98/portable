var searchData=
[
  ['_5f_5fbrkval',['__brkval',['../_free_stack_8h.html#ad193a2cc121e0d4614a1c21eb463fb56',1,'FreeStack.h']]],
  ['_5f_5fbss_5fend',['__bss_end',['../_free_stack_8h.html#adbad17f740c2d7f2bc4833681c93c932',1,'FreeStack.h']]]
];
